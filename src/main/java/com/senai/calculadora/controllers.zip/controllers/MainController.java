package com.senai.calculadora.controllers;

import com.senai.calculadora.dtos.EntradaDto;
import com.senai.calculadora.dtos.ResultadoDto;
import com.senai.calculadora.services.CalculadoraService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/calculadora")
public class MainController {

    private final CalculadoraService calculadoraService;

    public MainController(CalculadoraService service) {
        this.calculadoraService = service;
    }

    @PostMapping("/adicionar")
    //modificador de acesso
    //tipo de retorno **exclusivo resposeentity
    //<tipo de retorno>
    //nome do metodo
    //1(de json para java)
    //2(é o parametro de entetrada de dados)
    //3(instancia/variavel)
    public ResponseEntity<ResultadoDto> adicionar(@RequestBody EntradaDto dto){
        ResultadoDto saida = calculadoraService.adicionar(dto);
        return ResponseEntity.ok().body(saida);
    }


    @PostMapping("/subtrair")
    public ResponseEntity<ResultadoDto> subtrair(@RequestBody EntradaDto entrada){
        ResultadoDto saida = calculadoraService.subtrair(entrada);
        return ResponseEntity.ok().body(saida);
    }


    @PostMapping("/multiplicar")
    public ResponseEntity<ResultadoDto> multiplicar(@RequestBody EntradaDto entrada){
        ResultadoDto saida = calculadoraService.multiplicar(entrada);
        return ResponseEntity.ok().body(saida);
    }


    @PostMapping("/dividir")
    public ResponseEntity<ResultadoDto> dividir(@RequestBody EntradaDto entrada){
        ResultadoDto saida = calculadoraService.multiplicar(entrada);
        return ResponseEntity.ok().body(saida);
    }

}
