package com.senai.calculadora.dtos;

public class EntradaDto {

    private Float num1;
    private Float num2;

    public EntradaDto() {
    }

    public Float getNum1() {
        return num1;
    }

    public void setNum1(Float num1) {
        this.num1 = num1;
    }

    public Float getNum2() {
        return num2;
    }

    public void setNum2(Float num2) {
        this.num2 = num2;
    }
}
