package com.senai.calculadora.dtos;

public class ResultadoDto {

    private Float resultado;
    private Float num1;
    private Float num2;

    public ResultadoDto() {
    }

    public Float resultado() {
        return resultado;
    }

    public void setResultado(Float resultado) {
        this.resultado = resultado;
    }

    public Float num1() {
        return num1;
    }

    public void setNum1(Float num1) {
        this.num1 = num1;
    }

    public Float num2() {
        return num2;
    }

    public void setNum2(Float num2) {
        this.num2 = num2;
    }
}
