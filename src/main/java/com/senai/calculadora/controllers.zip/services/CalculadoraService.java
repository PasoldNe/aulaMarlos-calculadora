package com.senai.calculadora.services;

import com.senai.calculadora.dtos.EntradaDto;
import com.senai.calculadora.dtos.ResultadoDto;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

@Service
public class CalculadoraService {


    public ResultadoDto adicionar(EntradaDto entrada){
        ResultadoDto saida = new ResultadoDto();
        saida.setNum1(entrada.getNum1());
        saida.setNum2(entrada.getNum2());
        saida.setResultado(entrada.getNum1()+ entrada.getNum2());
        return saida;
    }

    public ResultadoDto subtrair(EntradaDto entrada){
        ResultadoDto saida = new ResultadoDto();
        saida.setNum1(entrada.getNum1());
        saida.setNum2(entrada.getNum2());
        saida.setResultado(entrada.getNum1() - entrada.getNum2());
        return saida;
    }

    public ResultadoDto dividir (EntradaDto entrada){
        ResultadoDto saida = new ResultadoDto();
        saida.setNum1(entrada.getNum1());

        if (entrada.getNum2() != 0){
            saida.setNum2(entrada.getNum2());
        } else {
            saida.setNum2(entrada.getNum1());
        }
        saida.setResultado(entrada.getNum1() / entrada.getNum2());
        return saida;
    }

    public ResultadoDto multiplicar (EntradaDto entrada){
        ResultadoDto saida = new ResultadoDto();
        saida.setNum1(entrada.getNum1());
        saida.setNum2(entrada.getNum2());
        saida.setResultado(entrada.getNum1() * entrada.getNum2());
        return saida;
    }
}
